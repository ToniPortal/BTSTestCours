package Java.controle;

public class cartemere extends ordinateur {

    public cartemere(String touche, int typedisque, String marque) {
        super(touche, typedisque, marque);
        // TODO Auto-generated constructor stub
    }

    String marque = "asus";

}
