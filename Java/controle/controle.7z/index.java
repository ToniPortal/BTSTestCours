package Java.controle;

public class index {

    public static void main(String[] args) {

        ordinateur O = new ordinateur(null, 1, null);
        System.out.println(O.toString());
    }
    
}
