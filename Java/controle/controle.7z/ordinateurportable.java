package Java.controle;

public class ordinateurportable extends ordinateur {

    public ordinateurportable(String touche, int typedisque, String marque) {
        super(touche, typedisque, marque);
        //TODO Auto-generated constructor stub
    }
    
    public int localisationX = 156;
    public int localisationY = 185;
    
}
